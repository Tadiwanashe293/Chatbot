#conversion
##as() to use convert one data type into anothre
a=9L
num1=as.numeric(9L)
num1
typeof(num1)

b=9
num2=as.integer(9)
num2
typeof(num2)

c=5L
num3=as.complex(5L)
num3
typeof(num3)

d=9
num4=as.logical(9)
num4
typeof(num4)

e=9
num5=as.character(9)
num5
typeof(num5)

f=a
num6=as.integer(a)
num6
typeof(num6)

g<-s
num7=as.numeric(s)
num7
typeof(num7)

b=z
num8=as.logical(z)
num8
typeof(num8)

h=90.78
num9=as.integer(90.78)
num9
typeof(num9)

#arithmitic value as well as vector value

a=8
b=7
c=a+b
c
C<-c(8,7)
c

a=8
b=7
c=a+b
c

d=8
e=7
f=d-e
f

g=8
h=7
i=g-h
i

j=8
k=7
l = j / k
l

m=8
n=7
o=m/n
o

X<-c(1,2,3,4,5,67)
X
a=9
b=4
a>b
a<b
a==b
a>=b
a<=b
a|b
a&b
a!=b
a1=a<b
a1