#commands


#comparsion data filter cmd
#showed command to view data(order by col name desc,ase)
#display first n rows use limit fun.
#right operator=match a pattern(%)
#aggrrigate fun()=count,avf,min,max,summery
#group by(madea grp of similar type of thing)
#in fun()(match only one value)
library(shiny)

library(leaflet)
library(plotly)
library(dplyr)


