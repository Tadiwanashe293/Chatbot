Q. Consider an implementation of unsorted single linked list. 
Suppose it has its representation with a head and a tail pointer 
(i.e. pointers to the first and last nodes of the linked list). 
Given the representation, which of the following operation can not be implemented in O(1) time?


d) Deletion of the last node of the linked list